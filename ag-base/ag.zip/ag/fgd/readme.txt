This is the Worldcraft FGD file for the AG CTF mode.
It's made by the "When It's Done team" - http://www.planethalflife.com/whenitsdone/.
Hopefully other mods will use the same so we can share the maps.
