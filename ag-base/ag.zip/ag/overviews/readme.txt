Map Overviews
Authors:	Stig & Jugger
Contact:	stig@stig3d.com (OR) jugger1@blueyonder.co.uk


Instructions:

Extract zip contents to your "Half-life/valve/overviews" folder.
Simple!