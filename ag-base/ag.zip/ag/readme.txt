A thing that can make you get started easily is to add this in the bottom of your config.cfg:
bind "F12" "+commandmenu" 

If you hit F12 in the game you get a nice menu with most of AG's features.

If you want to know more about Adrenaline Gamer then read it all in docs/index.htm

Have fun!
bullit@planethalflife.com
www.planethalflife.com/agmod

Liability: (or lack thereof)
IN NO EVENT WHATSOEVER SHALL bullit@planethalflife.com BE LIABLE FOR ANY DAMAGES WHATSOEVER (INCLUDING, WITHOUT LIMITATION, DIRECT OR INDIRECT DAMAGES, DAMAGES FOR LOSS OF PROFITS, BUSINESS INTERRUPTION, LOSS OF INFORMATION) RESULTING FROM THE USE OR INABILITY TO USE THE PROGRAMS AND FILES EVEN IF bullit@planethalflife.com HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. Without limiting the generality of the foregoing, no warranty is made that the enclosed software will do anything you want it to, or be error free. USING THIS SOFTWARE IMPLIES AGREEMENT TO THESE TERMS.
This version of AdrenalineGamer Mod is provided free of charge and may be freely downloaded and redistributed under the condition that all files in the original distribution remain in the distribution and that all redistribution sites must inform (in the form of a hypertext link, etc.) users of the original place of distribution. No person or group shall profit from the redistribution of this software in any form without the consent of bullit@planethalflife.com.
In other words, do not put this program onto a CD containing shareware/freeware programs that will be sold without first consulting bullit@planethalflife.com);
